
(function(compId){var _=null,y=true,n=false,x12='break-word',x94='176px',x74='ellipse',x137='25px',x124='235px',x83='rgb(0, 0, 0)',x77='202px',e40='${KFC-Logos-HD}',x76='95px',e57='${fried-chicken_Vector_Clipart}',x116='Text5',x141='rgba(196,0,0,1.00)',x100='rgba(107,0,0,1)',e48='${Text11}',e81='${Ellipse}',i='none',x122='139px',x101='_1453371461854-product',x82='Rectangle3',e44='${Rectangle}',x90='rgba(255,255,255,1)',e38='${burger3}',x85='500px',xc='rgba(0,0,0,1)',x79='100px',x1='6.0.0',x33='nowrap',x110='Rectangle5',x2='5.0.0',x30='35',e109='${Rectangle4}',x4='both',x111='83px',x126='Rectangle6',x72='1',x95='40px',x17='15',x69='540px',p='px',o='opacity',x99='319px',e46='${combos}',x84='98px',x114='plastic-cup-icon2',x149='332px',x119='38px',x10='24',e96='${Rectangle3}',e62='${Text12}',x127='109px',x105='171px',x103='Text3',x31='700',e59='${Text7}',x140='99px',x18='damion, sans-serif',x75='Text2',x106='517px',e66='${Text2}',x155='Text16',x148='true',x153='66px',x3='6.0.0.400',x152='107px',e65='${Text10}',x97='Rectangle4',lf='left',x151='284px',x150='110px',x129='rgba(102,0,0,1.00)',e136='${Rectangle6}',e64='${snacks}',e60='${Text9}',x154='rgba(207,207,207,1.00)',e52='${_1024px-KFC_logosvg}',bg='background-color',x146='rgba(195,195,195,1.00)',x70='auto',e42='${Text}',e58='${order1}',e45='${french-fries-vector-clipart-1}',x5='rgba(196,0,0,1)',tp='top',x143='47px',x19='400',x142='93px',x139='307px',x88='_1460361923649-product',e51='${BACK}',x138='11px',x130='_1434094805519-product',x135='148px',x134='516px',e53='${bg}',x68='551px',x6='rgba(0,0,0,0)',x145='27px',x78='362px',e50='${burger2}',x120='Text6',x98='87px',x128='277px',e125='${Rectangle5}',x123='511px',x118='295px',e43='${plastic-cup-icon}',x='text',m='rect',x67='0px',e55='${Rectangle2}',h='height',x93='518px',e56='${burger1}',x113='334px',x112='492px',e39='${burger4}',x107='159px',x73='Ellipse',x108='37px',e41='${burgers}',x87='rgba(107,0,0,1.00)',x37='rgba(255,255,255,1.00)',x144='172px',e49='${btn1}',e54='${orders}',x71='50%',x11='Arial, Helvetica, sans-serif',x28='56',l='normal',e61='${burger5}',e47='${Rhiannon-Bizon-burger}',x86='314px',e63='${Text4}',w='width',x92='162px',g='image',x132='Text7';var g22='burger1.jpeg',g89='1460361923649-product.jpeg',g14='french-fries-vector-clipart-1.jpg',g24='burger3.jpeg',g102='1453371461854-product.jpeg',g20='KFC-Logos-HD.jpg',g13='fried-chicken_Vector_Clipart.png',g131='1434094805519-product.jpeg',g8='1024px-KFC_logo.svg.png',g15='Rhiannon-Bizon-burger.png',g115='plastic-cup-icon2.jpg',g7='plastic-cup-icon.jpg',g23='burger2.jpeg',g26='burger5.jpeg',g21='bg.jpg',g25='burger4.jpeg';var s9="<p style=\"margin: 0px;\"><span style=\"font-family: Verdana, Geneva, sans-serif; font-weight: 700; font-size: 72px;\">WELCOME TO</span></p>",s117="<p style=\"margin: 0px;\">​<span style=\"font-size: 30px; font-weight: 700;\">DELIVERY</span></p>",s121="<p style=\"margin: 0px;\">​ORDER NOW</p>",s80="<p style=\"margin: 0px;\">​<span style=\"font-size: 72px;\">Lets Order!</span></p>",s104="<p style=\"margin: 0px;\">​<span style=\"font-size: 35px;\">COMBOS</span></p>",s34="<p style=\"margin: 0px;\">​150 PKR</p>",s29="<p style=\"margin: 0px;\">​230 PKR</p>",s147="<p style=\"margin: 0px;\">​BACK TO MAIN</p>",s35="<p style=\"margin: 0px;\">​350 PKR</p>",s91="<p style=\"margin: 0px;\"><span style=\"font-size: 35px;\">BURGERS</span></p>",s27="<p style=\"margin: 0px;\">​<span style=\"font-size: 70px; font-weight: 700; font-family: 'Lucida Sans Unicode', 'Lucida Grande', sans-serif;\">BURGERS</span></p>",s16="<p style=\"margin: 0px;\">​<span style=\"color: rgb(158, 0, 0); font-size: 144px; font-family: brush-script-std, sans-serif;\">Feeling </span><span style=\"font-size: 144px; font-family: brush-script-std, sans-serif;\">Hungry?</span></p>",s36="<p style=\"margin: 0px;\">​370 PKR</p>",s32="<p style=\"margin: 0px;\">​430 PKR</p>",s133="<p style=\"margin: 0px;\">​SNACKS</p>";var im='images/',aud='media/',vid='media/',js='js/',fonts={'aladin, sans-serif':'<script src=\"http://use.edgefonts.net/aladin:n4:all.js\"></script>','aguafina-script, cursive':'<script src=\"http://use.edgefonts.net/aguafina-script:n4:all.js\"></script>','brush-script-std, sans-serif':'<script src=\"http://use.edgefonts.net/brush-script-std:n4:all.js\"></script>','damion, sans-serif':'<script src=\"http://use.edgefonts.net/damion:n4:all.js\"></script>'},opts={'gAudioPreloadPreference':'auto','gVideoPreloadPreference':'auto'},resources=[],scripts=[],symbols={"stage":{v:x1,mv:x2,b:x3,stf:x4,cg:x4,rI:n,cn:{dom:[{id:'Rectangle',t:m,r:['0px','276px','0px','185px','auto','auto'],o:'1',f:[x5],s:[0,"rgb(0, 0, 0)",i]},{id:'plastic-cup-icon',t:g,r:['59px','977px','382px','461px','auto','auto'],o:'1',f:[x6,im+g7,'0px','0px']},{id:'_1024px-KFC_logosvg',t:g,r:['312px','1980px','431px','431px','auto','auto'],o:'1',f:[x6,im+g8,'0px','0px']},{id:'Text',t:x,r:['-600px','696px','556px','93px','auto','auto'],o:'1',text:s9,n:[x11,[x10,],"rgba(207,4,4,1.00)",l,i,"",x12,l]},{id:'fried-chicken_Vector_Clipart',t:g,r:['582px','1017px','440px','440px','auto','auto'],o:'1',f:[x6,im+g13,'0px','0px']},{id:'french-fries-vector-clipart-1',t:g,r:['242px','1180px','258px','258px','auto','auto'],o:'1',f:[x6,im+g14,'0px','0px']},{id:'Rhiannon-Bizon-burger',t:g,r:['312px','1113px','551px','413px','auto','auto'],o:'1',f:[x6,im+g15,'0px','0px']},{id:'btn1',symbolName:'btn1',t:m,r:['252px','1932px','551','540','auto','auto'],o:'1'},{id:'Text4',t:x,r:['219px','-388px','618px','376px','auto','auto'],o:'1',text:s16,align:"center",n:[x18,[x17,p],"rgba(255,255,255,1)",x19,i,l,x12,l],ts:["","","","",i]},{id:'Rectangle2',t:m,r:['0px','-14px','1080px','4px','auto','auto'],f:[x5],s:[0,"rgb(0, 0, 0)",i]},{id:'KFC-Logos-HD',t:g,r:['323px','-550px','402px','550px','auto','auto'],f:[x6,im+g20,'0px','0px']},{id:'snacks',symbolName:'snacks',t:m,r:['552px','-572px','500','500','auto','auto'],tf:[[],[],[],['1','0.984']]},{id:'combos',symbolName:'combos',t:m,r:['1138px','636','500','500','auto','auto']},{id:'burgers',symbolName:'burgers',t:m,r:['28','1976px','500','500','auto','auto']},{id:'orders',symbolName:'orders',t:m,r:['-552px','1298px','500','492','auto','auto']},{id:'bg',t:g,r:['-3418px','-10px','3413px','1920px','auto','auto'],f:[x6,im+g21,'0px','0px'],filter:[0,0,1,1,0,0,0,22,"rgba(0,0,0,0)",0,0,0]},{id:'burger1',t:g,r:['70px','118px','50px','50px','auto','auto'],o:'0',f:[x6,im+g22,'0px','0px']},{id:'burger2',t:g,r:['524px','118px','50px','50px','auto','auto'],o:'0',f:[x6,im+g23,'0px','0px']},{id:'burger3',t:g,r:['70px','702px','50px','50px','auto','auto'],o:'0',f:[x6,im+g24,'0px','0px']},{id:'burger4',t:g,r:['524px','702px','50px','50px','auto','auto'],o:'0',f:[x6,im+g25,'0px','0px']},{id:'burger5',t:g,r:['262px','1296px','50px','50px','auto','auto'],o:'0',f:[x6,im+g26,'0px','0px']},{id:'Text2',t:x,r:['396px','-90px','348px','76px','auto','auto'],text:s27,align:"left",n:[x11,[x28,p],"rgba(207,4,4,1)",x19,i,l,x12,l],ts:["","","","",i]},{id:'BACK',symbolName:'BACK',t:m,r:['-408px','-9px','332','110','auto','auto']},{id:'Text7',t:x,r:['388px','571px','152px','47px','auto','auto'],o:'0',text:s29,align:"left",n:[x11,[x30,p],"rgba(203,2,2,1.00)",x31,i,l,x12,l],ts:["","","","",i]},{id:'Text9',t:x,r:['876px','571px','auto','auto','auto','auto'],o:'0',text:s32,align:"left",n:[x11,[x30,p],"rgba(203,2,2,1)",x31,i,l,x12,x33],ts:["","","","",i]},{id:'Text10',t:x,r:['394px','1154px','auto','auto','auto','auto'],o:'0',text:s34,align:"left",n:[x11,[x30,p],"rgba(203,2,2,1)",x31,i,l,x12,x33],ts:["","","","",i]},{id:'Text11',t:x,r:['866px','1154px','auto','auto','auto','auto'],o:'0',text:s35,align:"left",n:[x11,[x30,p],"rgba(203,2,2,1)",x31,i,l,x12,x33],ts:["","","","",i]},{id:'Text12',t:x,r:['664px','1802px','auto','auto','auto','auto'],o:'0',text:s36,align:"left",n:[x11,[x30,p],"rgba(203,2,2,1)",x31,i,l,x12,x33],ts:["","","","",i]},{id:'order1',symbolName:'order1',t:m,r:['1134px','-14','284','107','auto','auto']}],style:{'${Stage}':{isStage:true,r:['null','null','1080px','1920px','auto','auto'],overflow:'hidden',f:[x37]}}},tt:{d:22883,a:y,l:{"main":8887,"main1":9750,"burger":13500,"burger1":14250,"blur":20336,"blury":21750},data:[["eid168",w,17000,500,"easeOutQuart",e38,'50px','500px'],["eid172",o,17250,500,"easeOutQuart",e39,'0','1'],["eid166",h,17000,500,"easeOutQuart",e38,'50px','500px'],["eid53",lf,9750,500,"easeOutQuart",e40,'307px','323px'],["eid116",lf,13750,359,"easeOutQuart",e40,'323px','-887px'],["eid114",lf,13750,359,"easeOutQuart",e41,'28px','-1182px'],["eid1",lf,0,1200,"easeOutQuart",e42,'-600px','230px'],["eid11",tp,5250,1000,"easeOutQuart",e43,'977px','988px'],["eid108",tp,9250,500,"easeOutQuart",e43,'988px','878px'],["eid25",w,3500,500,"easeOutQuart",e44,'0px','1080px'],["eid9",tp,4500,1000,"easeOutQuart",e45,'1180px','1191px'],["eid110",tp,9250,500,"easeOutQuart",e45,'1191px','1081px'],["eid121",tp,13750,359,"easeOutQuart",e46,'636px','642px'],["eid55",tp,9750,500,"easeOutQuart",e40,'-550px','0px'],["eid117",tp,13750,359,"easeOutQuart",e40,'0px','6px'],["eid13",tp,3750,1000,"easeOutQuart",e47,'1113px','1105px'],["eid100",tp,9250,500,"easeOutQuart",e47,'1105px','995px'],["eid170",o,17000,500,"easeOutQuart",e38,'0','1'],["eid188",o,18250,500,"easeOutQuart",e48,'0','1'],["eid19",lf,7500,1000,"easeOutQuart",e49,'252px','264px'],["eid97",lf,9250,500,"easeOutQuart",e49,'264px','2184px'],["eid156",w,16750,500,"easeOutQuart",e50,'50px','500px'],["eid196",tp,19250,500,"easeOutQuart",e51,'-9px','-14px'],["eid101",lf,9250,500,"easeOutQuart",e52,'312px','2232px'],["eid124",tp,14870,6771,"easeOutQuart",e53,'-10px','1px'],["eid66",tp,11250,500,"easeOutQuart",e54,'1298px','1290px'],["eid119",tp,13750,359,"easeOutQuart",e54,'1290px','1296px'],["eid40",h,9000,750,"easeOutQuart",e55,'4px','1934px'],["eid162",w,16500,500,"easeOutQuart",e56,'50px','500px'],["eid96",tp,9250,500,"easeOutQuart",e57,'1017px','907px'],["eid198",lf,19000,500,"easeOutQuart",e58,'1134px','794px'],["eid194",lf,19250,500,"easeOutQuart",e51,'-408px','-26px'],["eid192",o,17500,500,"easeOutQuart",e59,'0','1'],["eid8",lf,4500,1000,"easeOutQuart",e45,'1138px','242px'],["eid109",lf,9250,500,"easeOutQuart",e45,'242px','2162px'],["eid60",lf,12250,500,"easeOutQuart",e46,'1138px','558px'],["eid120",lf,13750,359,"easeOutQuart",e46,'558px','-652px'],["eid176",w,17250,500,"easeOutQuart",e39,'50px','500px'],["eid154",h,16750,500,"easeOutQuart",e50,'50px','500px'],["eid12",lf,6000,1000,"easeOutQuart",e57,'1226px','582px'],["eid95",lf,9250,500,"easeOutQuart",e57,'582px','2502px'],["eid7",lf,3750,1000,"easeOutQuart",e47,'-556px','312px'],["eid99",lf,9250,500,"easeOutQuart",e47,'312px','2232px'],["eid190",o,17750,500,"easeOutQuart",e60,'0','1'],["eid182",o,17500,500,"easeOutQuart",e61,'0','1'],["eid111",lf,14000,870,"easeOutQuart",e53,'-3418px','-2323px'],["eid123",lf,14870,6771,"easeOutQuart",e53,'-2323px','-173px'],["eid186",o,18500,500,"easeOutQuart",e62,'0','1'],["eid158",o,16750,500,"easeOutQuart",e50,'0','1'],["eid180",w,17500,500,"easeOutQuart",e61,'50px','556px'],["eid21",lf,2750,750,"easeOutQuart",e63,'219px','215px'],["eid105",lf,9250,500,"easeOutQuart",e63,'215px','2135px'],["eid178",h,17500,500,"easeOutQuart",e61,'50px','556px'],["eid164",o,16500,500,"easeOutQuart",e56,'0','1'],["eid70",tp,11750,500,"easeOutQuart",e64,'-572px','1286px'],["eid113",tp,13750,359,"easeOutQuart",e64,'1286px','1292px'],["eid132","filter.blur",20336,1305,"easeOutQuart",e53,'0px','22px'],["eid201","filter.blur",21641,1242,"easeOutQuart",e53,'22px','0px'],["eid184",o,18000,500,"easeOutQuart",e65,'0','1'],["eid86",o,0,0,"easeOutQuart",e42,'1','1'],["eid4",o,1200,800,"easeOutQuart",e42,'1','0'],["eid50",o,9000,0,"easeOutQuart",e42,'0','0'],["eid51",o,9500,0,"easeOutQuart",e42,'0','0'],["eid17",tp,7500,1000,"easeOutQuart",e49,'1932px','1512px'],["eid98",tp,9250,500,"easeOutQuart",e49,'1512px','1402px'],["eid174",h,17250,500,"easeOutQuart",e39,'50px','500px'],["eid2",tp,0,1200,"easeOutQuart",e42,'696px','680px'],["eid64",lf,11250,500,"easeOutQuart",e54,'-552px','28px'],["eid118",lf,13750,359,"easeOutQuart",e54,'28px','-1182px'],["eid10",lf,5250,1000,"easeOutQuart",e43,'-509px','59px'],["eid107",lf,9250,500,"easeOutQuart",e43,'59px','1979px'],["eid62",tp,10750,500,"easeOutQuart",e41,'1976px','636px'],["eid115",tp,13750,359,"easeOutQuart",e41,'636px','642px'],["eid200",tp,16500,500,"easeOutQuart",e66,'-90px','6px'],["eid160",h,16500,500,"easeOutQuart",e56,'50px','500px'],["eid104",tp,9250,500,"easeOutQuart",e44,'276px','166px'],["eid3",tp,1200,1800,"easeOutQuart",e52,'1980px','586px'],["eid102",tp,9250,500,"easeOutQuart",e52,'586px','476px'],["eid103",lf,9250,500,"easeOutQuart",e44,'0px','1920px'],["eid112",lf,13750,359,"easeOutQuart",e64,'552px','-658px'],["eid23",tp,2750,750,"easeOutQuart",e63,'-388px','116px'],["eid106",tp,9250,500,"easeOutQuart",e63,'116px','6px']]}},"btn1":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{r:[x67,x67,x68,x69,x70,x70],br:[x71,x71,x71,x71],o:x72,id:x73,s:[0,xc,i],t:x74,f:[x5]},{t:x,id:x75,ts:['','','','',i],n:[x11,[24,p],x37,x19,i,l,x12,l],r:[x76,x77,x78,x79,x70,x70],text:s80,o:x72,align:lf}],style:{'${symbolSelector}':{r:[_,_,x68,x69]}}},tt:{d:1630,a:y,l:{"start":250,"end":1250},data:[["eid29",bg,250,380,"linear",e81,'rgba(196,0,0,1)','rgba(87,0,0,1.00)'],["eid30",bg,1250,380,"linear",e81,'rgba(87,0,0,1)','rgba(196,0,0,1.00)'],["eid31",tp,250,380,"linear",e66,'200px','160px'],["eid32",tp,1250,380,"linear",e66,'160px','202px']]}},"burgers":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{t:m,id:x82,s:[0,x83,i],r:[x84,x85,x86,x67,x70,x70],f:[x87]},{r:[x67,x67,x85,x85,x70,x70],id:x88,t:g,f:[x6,im+g89,x67,x67]},{n:[x11,[24,p],x90,x19,i,l,x12,l],t:x,align:lf,id:x75,ts:['','','','',i],text:s91,r:[x92,x93,x94,x95,x70,x70]}],style:{'${symbolSelector}':{r:[_,_,x85,x85]}}},tt:{d:2000,a:y,l:{"start":500,"end":1500},data:[["eid57",h,500,500,"easeOutQuart",e96,'0px','90px'],["eid58",h,1500,500,"easeOutQuart",e96,'90px','0px']]}},"combos":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{t:m,id:x97,s:[0,x83,i],r:[x98,x85,x99,x67,x70,x70],f:[x100]},{r:[x67,x67,x85,x85,x70,x70],id:x101,t:g,f:[x6,im+g102,x67,x67]},{n:[x11,[24,p],x90,x19,i,l,x12,l],t:x,align:lf,id:x103,ts:['','','','',i],text:s104,r:[x105,x106,x107,x108,x70,x70]}],style:{'${symbolSelector}':{r:[_,_,x85,x85]}}},tt:{d:2000,a:y,l:{"start":500,"end":1500},data:[["eid72",h,500,500,"easeOutQuart",e109,'0px','79px'],["eid73",h,1500,500,"easeOutQuart",e109,'79px','0px']]}},"orders":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{t:m,id:x110,s:[0,x83,i],r:[x111,x112,x113,x67,x70,x70],f:[x100]},{r:[x67,x67,x85,x112,x70,x70],id:x114,t:g,f:[x6,im+g115,x67,x67]},{n:[x11,[24,p],x90,x19,i,l,x12,l],t:x,align:lf,id:x116,ts:['','','','',i],text:s117,r:[x94,x118,x92,x119,x70,x70]},{n:[x11,[35,p],x90,x19,i,l,x12,l],t:x,align:lf,id:x120,ts:['','','','',i],text:s121,r:[x122,x123,x124,x119,x70,x70]}],style:{'${symbolSelector}':{r:[_,_,x85,x112]}}},tt:{d:2250,a:y,l:{"start":500,"end":1750},data:[["eid76",h,500,500,"easeOutQuart",e125,'0px','78px'],["eid77",h,1750,500,"easeOutQuart",e125,'78px','0px']]}},"snacks":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{t:m,id:x126,s:[0,x83,i],r:[x127,x85,x128,x67,x70,x70],f:[x129]},{r:[x67,x67,x85,x85,x70,x70],id:x130,t:g,f:[x6,im+g131,x67,x67]},{n:[x11,[35,p],x90,x19,i,l,x12,l],t:x,align:lf,id:x132,ts:['','','','',i],text:s133,r:[x94,x134,x135,x119,x70,x70]}],style:{'${symbolSelector}':{r:[_,_,x85,x85]}}},tt:{d:2000,a:y,l:{"start":500,"end":1500},data:[["eid81",h,500,500,"easeOutQuart",e136,'0px','71px'],["eid82",h,1500,500,"easeOutQuart",e136,'71px','0px']]}},"BACK":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{r:[x137,x138,x139,x140,x70,x70],id:x82,s:[0,x83,i],t:m,f:[x141]},{r:[x142,x143,x144,x145,x70,x70],ts:['','','','',i],n:[x11,[24,p],x146,x19,i,l,x12,l],id:x116,text:s147,align:lf,t:x}],style:{'${symbolSelector}':{isStage:x148,r:[undefined,undefined,x149,x150]}}},tt:{d:10000,a:y,l:{"start":8500,"end":9500},data:[["eid137",bg,8500,500,"easeOutQuart",e96,'rgba(196,0,0,1.00)','rgba(0,0,0,1.00)'],["eid138",bg,9500,500,"easeOutQuart",e96,xc,'rgba(196,0,0,1.00)']]}},"order1":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{r:[x67,x67,x151,x152,x70,x70],id:x97,s:[0,x83,i],t:m,f:[x5]},{r:[x153,x95,x70,x70,x70,x70],ts:['','','','',i],n:[x11,[24,p],x154,x19,i,l,x12,x33],id:x155,text:s121,align:lf,t:x}],style:{'${symbolSelector}':{isStage:x148,r:[undefined,undefined,x151,x152]}}},tt:{d:2000,a:y,l:{"start":500,"end":1500},data:[["eid139",bg,500,500,"easeOutQuart",e109,'rgba(196,0,0,1)','rgba(0,0,0,1.00)'],["eid140",bg,1500,500,"easeOutQuart",e109,xc,'rgba(196,0,0,1.00)']]}}};AdobeEdge.registerCompositionDefn(compId,symbols,fonts,scripts,resources,opts);})("EDGE-5336709");
(function($,Edge,compId){var Composition=Edge.Composition,Symbol=Edge.Symbol;Edge.registerEventBinding(compId,function($){
//Edge symbol: 'stage'
(function(symbolName){Symbol.bindElementAction(compId,symbolName,"${btn1}","touchstart",function(sym,e){sym.getSymbol("btn1").play("begin");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${btn1}","touchend",function(sym,e){sym.getSymbol("btn1").play("end");sym.play("main");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",8500,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${burgers}","touchstart",function(sym,e){sym.getSymbol("burgers").play("start");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${burgers}","touchend",function(sym,e){sym.getSymbol("burgers").play("end");sym.play("burger");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${combos}","touchstart",function(sym,e){sym.getSymbol("combos").play("start");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${combos}","touchend",function(sym,e){sym.getSymbol("combos").play("end");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${orders}","touchstart",function(sym,e){sym.getSymbol("orders").play("start");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${orders}","touchend",function(sym,e){sym.getSymbol("orders").play("end");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${snacks}","touchstart",function(sym,e){sym.getSymbol("snacks").play("start");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${snacks}","touchend",function(sym,e){sym.getSymbol("snacks").play("end");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",13000,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${BACK}","touchstart",function(sym,e){sym.getSymbol("BACK").play("start");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${BACK}","touchend",function(sym,e){sym.getSymbol("BACK").play("end");sym.play("main1");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${order1}","touchstart",function(sym,e){sym.getSymbol("order1").play("start");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${order1}","touchend",function(sym,e){sym.getSymbol("order1").play("end");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",20000,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",21641,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",22883,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${burger1}","touchstart",function(sym,e){sym.play("blur");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${burger1}","touchend",function(sym,e){sym.play("blury");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${burger2}","touchstart",function(sym,e){sym.play("blur");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${burger2}","touchend",function(sym,e){sym.play("blury");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${burger3}","touchstart",function(sym,e){sym.play("blur");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${burger3}","touchend",function(sym,e){sym.play("blury");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${burger4}","touchstart",function(sym,e){sym.play("blur");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${burger4}","touchend",function(sym,e){sym.play("blury");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${burger5}","touchstart",function(sym,e){sym.play("blur");});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${burger5}","touchend",function(sym,e){sym.play("blury");});
//Edge binding end
})("stage");
//Edge symbol end:'stage'

//=========================================================

//Edge symbol: 'btn1'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",1630,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",630,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",0,function(sym,e){sym.stop();});
//Edge binding end
})("btn1");
//Edge symbol end:'btn1'

//=========================================================

//Edge symbol: 'burgers'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",1000,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",2000,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",250,function(sym,e){sym.stop();});
//Edge binding end
})("burgers");
//Edge symbol end:'burgers'

//=========================================================

//Edge symbol: 'combos'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",2000,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",1000,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",250,function(sym,e){sym.stop();});
//Edge binding end
})("combos");
//Edge symbol end:'combos'

//=========================================================

//Edge symbol: 'orders'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",2250,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",1000,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",138,function(sym,e){sym.stop();});
//Edge binding end
})("orders");
//Edge symbol end:'orders'

//=========================================================

//Edge symbol: 'snacks'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",1000,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",2000,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",138,function(sym,e){sym.stop();});
//Edge binding end
})("snacks");
//Edge symbol end:'snacks'

//=========================================================

//Edge symbol: 'BACK'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",10000,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",9000,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",8000,function(sym,e){sym.stop();});
//Edge binding end
})("BACK");
//Edge symbol end:'BACK'

//=========================================================

//Edge symbol: 'order1'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",2000,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",1000,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",250,function(sym,e){sym.stop();});
//Edge binding end
})("order1");
//Edge symbol end:'order1'
})})(AdobeEdge.$,AdobeEdge,"EDGE-5336709");